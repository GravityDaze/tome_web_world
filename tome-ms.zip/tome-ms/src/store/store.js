import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

const state = {
  //加载图片显示或者隐藏的参数
  loadingImg:true,
  //顶部导航切换状态值
  consoleShow:true,
  // 存储token
  token: localStorage.getItem('token') ? localStorage.getItem('token') : '',
  //userInfo代表用户登录信息
  userInfo:'13888888888',

}
const mutations = {
  //ceo首页顶部导航切换值获取的方法
  getUsercount(state, obj) {
    console.log("传过来的n:", obj)
    // this.state.isControl = obj
    // this.state.consoleShow = obj
  },
  // 修改token，并将token存入localStorage
  getToken(state, obj) {
    console.log('触发了机关',obj,obj.token)
    this.state.token = obj.token;
    localStorage.setItem('token', obj.token);
    localStorage.setItem('isControl', true);
    this.state.userInfo =obj.userInfo
    this.state.consoleShow = false
  },
  loginOut(state){
    this.state.token=''
    console.log('此时的token是：',this.state.token)
    localStorage.removeItem('token')
    this.state.consoleShow = true
  },
  isLoadingImg(state,obj){
    this.state.loadingImg=obj
  }

}
const actions = {
}
// 以下是将对象注册到Vuex实例中({state,mutations,actions})
export default new Vuex.Store({
  state,
  mutations,
  actions
})

